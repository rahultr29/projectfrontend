import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rout',
  templateUrl: './app.routing.html',
  styleUrls: ['./app.routing.css']
})
export class AppRouting{
}
